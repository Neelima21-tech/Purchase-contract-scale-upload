sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("com.wl.mm.zolacontrscale.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  