sap.ui.define(
    [
        "sap/ui/core/mvc/Controller",
        "sap/ui/export/Spreadsheet",
    ],
    function(Controller,Spreadsheet) {
      "use strict";
  
      return Controller.extend("com.wl.mm.zolacontrscale.controller.display", {
        onInit: function() {
        },
        onBack : function () {
          this.getOwnerComponent().getRouter().navTo("RouteView1"); 
        },
        onDownloadPress: function () {
          {
              var aCols, oRowBinding, oSettings, oSheet, oTable;
  
              if (!this._oTable) {
                  this._oTable = this.byId('dataTable');
              }
  
              oTable = this._oTable;
              oRowBinding = oTable.getBinding('items');
              aCols = [
                  { label: "Purchase Contract", property: "PurchaseContract", type: "String" },
                  { label: "Item", property: "PurchaseContractItem", type: "String" },
                  { label: "Condition Validity From Date", property: "ExcelValidFrom", type: "String" },
                  { label: "Condition Validity End Date", property: "ConditionValidityEndDate", type: "String" },
                  { label: "Condition Type", property: "ExcelCondition", type: "String" },                  
                  { label: "Condition Scale Quantity", property: "ConditionScaleQuantity", type: "String" },
                  { label: "Scale UOM", property: "ExcelScaleUOM", type: "String" },
                  { label: "Condition Rate Amount", property: "ConditionRateAmount", type: "String" },
                  { label: "Action", property: "action", type: "String"},
                  { label: "Status", property: "status", type: "String" },
                  { label: "Message", property: "message", type: "String" },
                  { label: "Error Details" , property:"IMessage", type: "String"}
                ];

                oRowBinding.oList.forEach(element => {
                  if(element.IMessage){
                      var infostring = element.IMessage.map( msgitem=> {
                          return msgitem.MessageType +": " + msgitem.Message;
          
                      }).join("\n");
                      element.IMessage = infostring;
                  } else {
                      element.IMessage = "";
                  }              
                  
              });
  
              oSettings = {
                  workbook: {
                      columns: aCols,
                      hierarchyLevel: 'Level'
                  },
                  dataSource: oRowBinding,
                  fileName: 'Purchase Contract (OLA) Scale Upload Logs.xlsx',
                  worker: false 
              };
  
              oSheet = new Spreadsheet(oSettings);
              oSheet.build().finally(function() {
                  oSheet.destroy();
              });
          }
      },
      onpressAction: function (oEvent) {
        var oButton =  oEvent.getSource();
        var oData = oButton.data("IMessage");
  
        var oTable = new sap.m.Table({
          columns: [
              new sap.m.Column({
                  header: new sap.m.Label({text: this._getTextfromi18n("INFO.CODE")}),
                  width:"30%"
              }),
              new sap.m.Column({
                  header: new sap.m.Label({text:  this._getTextfromi18n("INFO.MESSAGE")})
              })
          ]
      });
   
     
      var oModel = new sap.ui.model.json.JSONModel();
      oModel.setData(oData);
   
      oTable.bindItems({
          path: "/",
          template: new sap.m.ColumnListItem({
              cells: [
                  new sap.m.Text({text: "{MessageType}"}),
                  new sap.m.Text({text: "{Message}"})
              ]
          })
      });
   
     
      var oDialog = new sap.m.Dialog({
          title: this._getTextfromi18n("INFO.TITLE"),
          contentWidth: "700px",
          contentHeight: "300px",
          resizable: true,
          draggable: true,
          content: [oTable],
          beginButton: new sap.m.Button({
              text: "Close",
              press: function() {
                  oDialog.close();
              }
          })
      });
   
      
      oDialog.setModel(oModel);
       
      oDialog.open();
        
      },
      _getTextfromi18n : function(sKey, aPlaceholderParam){
        var oResourceModel = this.getView().getModel("i18n"),
          oBundle = oResourceModel.getResourceBundle(),
          sText = oBundle.getText(sKey,aPlaceholderParam);
          return sText;
      }

      });
    }
  );
  