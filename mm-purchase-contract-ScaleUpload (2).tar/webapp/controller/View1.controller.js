sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox",
    "sap/m/MessageToast",
    "sap/ui/export/Spreadsheet",
    "sap/ui/export/library",
    "sap/m/SearchField",
    "sap/ui/model/type/String",
    "sap/ui/table/Column",
    "sap/m/Column",
    "sap/m/Text",
    "sap/m/Label",
    "sap/ui/core/BusyIndicator",
  ],
  function (
    Controller,
    Filter,
    FilterOperator,
    MessageBox,
    MessageToast,
    Spreadsheet,
    exportLibrary,
    SearchField,
    TypeString,
    UIColumn,
    MColumn,
    Text,
    Label,
    BusyIndicator
  ) {
    "use strict";
    jQuery.sap.require("com.wl.mm.zolacontrscale.util.xlsx");
    return Controller.extend("com.wl.mm.zolacontrscale.controller.View1", {
      onInit: function () {
        this.oModel = this.getOwnerComponent().getModel(
          "API_PURCHASECONTRACT_PROCESS_SRV"
        );
        this._callODataService(); //test odata
        //multi material
        var oMultiInputWithSuggestions = this.byId(
          "idPurchaseingContract"
        );
        oMultiInputWithSuggestions.addValidator(this._onMultiInputValidate);
        this._oMultiInputWithSuggestions = oMultiInputWithSuggestions;
        this.oExecuteButton = this.byId("idPost");
      },

      _callODataService: function () {
        var oModel = this.oModel;
        var aFilters = [];
        oModel.read("/A_PurchaseContract", {
          filters: aFilters,
          success: function (oData) {
          },
          error: function (oError) {
           
          },
        });
      },

      _setButtonEnabled: function (bEnabled) {
        this.oExecuteButton.setEnabled(bEnabled);
      },

      //:-- contract help
      onValueHelpWithSuggestionsRequested: function () {
             
        this._oBasicSearchFieldWithSuggestions = new SearchField();

        this.pDialogWithSuggestions = this.loadFragment({
          name: "com.wl.mm.zolacontrscale.fragment.ValueHelpDialogFilterbarWithSuggestions",
        }).then(
          function (oDialogSuggestions) {
            var oFilterBar = oDialogSuggestions.getFilterBar(),
              oColumnProductCode;              
            this._oVHDWithSuggestions = oDialogSuggestions;
            this.getView().addDependent(oDialogSuggestions);
            // Set key fields for filtering in the Define Conditions Tab
            oDialogSuggestions.setRangeKeyFields([
              {
                label: this._getTextfromi18n("PC_VH_COL_PURCHASE_CNTRT"),
                key: "PurchaseContract",
                type: "string",
                typeInstance: new TypeString( {}, {
                    maxLength: 20,
                  }
                ),
              },
            ]);

            // Set Basic Search for FilterBar
            oFilterBar.setFilterBarExpanded(false);
            oFilterBar.setBasicSearch(this._oBasicSearchFieldWithSuggestions);

            // Trigger filter bar search when the basic search is fired
            this._oBasicSearchFieldWithSuggestions.attachSearch(function () {
              oFilterBar.search();
            });

            oDialogSuggestions.getTableAsync().then(
              function (oTable) {
                oTable.setModel(this.oModel);

                // For Desktop and tabled the default table is sap.ui.table.Table
                if (oTable.bindRows) {
                                  
                  // Bind rows to the ODataModel and add columns
                  oTable.bindAggregation("rows", {
                    path: "/A_PurchaseContract",
                    events: {
                      dataReceived: function () {
                        oDialogSuggestions.update();
                      },
                    },
                  });
                  oColumnProductCode = new UIColumn({
                    label: new Label({ text: "{i18n>PC_VH_COL_PURCHASE_CNTRT}" }),
                    template: new Text({ wrapping: false, text: "{PurchaseContract}" }),
                  });
                  oColumnProductCode.data({
                    fieldName: "PurchaseContract",
                  });
                  oTable.addColumn(oColumnProductCode);              
                }

                // For Mobile the default table is sap.m.Table
                if (oTable.bindItems) {              
                  // Bind items to the ODataModel and add columns
                  oTable.bindAggregation("items", {
                    path: "/A_PurchaseContract",
                    template: new ColumnListItem({
                      cells: [
                        new Label({ text: "{PurchaseContract}" }),                        
                      ],
                    }),
                    events: {
                      dataReceived: function () {
                        oDialogSuggestions.update();
                      },
                    },
                  });
                  oTable.addColumn(
                    new MColumn({ header: new Label({ text: "{i18n>PC_VH_COL_PURCHASE_CNTRT}" }) })
                  );                               
                                 }
                oDialogSuggestions.update();
              }.bind(this)
            );
            oDialogSuggestions.setTokens(
              this._oMultiInputWithSuggestions.getTokens()
            );
            oDialogSuggestions.open();
          }.bind(this)
        );
      },

      onValueHelpWithSuggestionsOkPress: function (oEvent) {
        var aContract = [];
        var aTokens = oEvent.getParameter("tokens");
        this._oMultiInputWithSuggestions.setTokens(aTokens);
        aTokens.forEach(function (oToken) {
          var sContractKey = oToken.getKey();
          aContract.push(sContractKey);
        }, this);
        // --filter
        var aFilter = [];
        aTokens.forEach((token) => {
          var oFilter = this._formFilter(token, "PurchaseContract");
          if (oFilter) aFilter.push(oFilter);
        });
        if (aContract.length > 0) {
          var oContractInput = this.getView().byId(
            "idPurchaseingContract"
          );
          var oModel = this.getView().getModel("localModel");
          // Set the collected contract to the model
          oModel.setProperty("/selectedMatCondition", aFilter);
          oModel.setProperty("/selectedMaterial", aContract);               
          oContractInput.removeAllTokens();
          aContract.forEach(function (sContract) {
            oContractInput.addToken(
              new sap.m.Token({ key: sContract, text: sContract })
            );
          });
          this.getView().byId("idPurchaseingContract").setValue("");          
        } else {
        }       
        this._oVHDWithSuggestions.close();
        this._onCtrInputChange();
        this.onValueChange(); 
      },

      onValueHelpWithSuggestionsCancelPress: function () {
        this._oVHDWithSuggestions.close();
        this._onCtrInputChange();
        this.onValueChange();
      },

      onFilterBarWithSuggestionsSearch: function (oEvent) {
        var sSearchQuery = this._oBasicSearchFieldWithSuggestions.getValue(),
          aSelectionSet = oEvent.getParameter("selectionSet"),
          aFilters =
            aSelectionSet &&
            aSelectionSet.reduce(function (aResult, oControl) {
              if (oControl.getValue()) {
                aResult.push(
                  new Filter({
                    path: oControl.getName(),
                    operator: FilterOperator.Contains,
                    value1: oControl.getValue(),
                  })
                );
              }

              return aResult;
            }, []);

        aFilters.push(
          new Filter({
            filters: [
              new Filter({
                path: "PurchaseContract",
                operator: FilterOperator.Contains,
                value1: sSearchQuery,
              })
            ]
          })
        );

        this._filterTableWithSuggestions(
          new Filter({
            filters: aFilters,
            and: true,
          })
        );
      },

      _filterTableWithSuggestions: function (oFilter) {
        var oVHD = this._oVHDWithSuggestions;
        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }
          oVHD.update();
        });
      },

      onValueHelpWithSuggestionsAfterClose: function () {
        this._oVHDWithSuggestions.destroy();
        this._onCtrInputChange();
        this.onValueChange();
      },
      _formFilter: function (oToken, sFieldPath) {
        var oFilterObj = {};
        var sKeyType = oToken
          .getAggregation("customData")[0]
          .getProperty("key");

        switch (sKeyType) {
          case "row": {
            oFilterObj = new Filter({
              path: sFieldPath,
              operator: FilterOperator.Contains,
              value1: oToken.getKey(),
            });
            break;
          }
          case "range": {
            var oValue = oToken
              .getAggregation("customData")[0]
              .getProperty("value");
            oFilterObj = new Filter({
              path: oValue.keyField,
              operator: FilterOperator[oValue.operation],
              value1: oValue.value1,
              value2: oValue.value2,
            });
          }
        }
        return oFilterObj;
      },
      onValueChange: async function () {
        //:--
        var contractFlag = false;
        var sContractValue = this.byId(
          "idPurchaseingContract"
        ).getValue();
        var sContractToken = this.byId("idPurchaseingContract").getTokens();//git
        var oModel = this.getOwnerComponent().getModel("API_PURCHASECONTRACT_PROCESS_SRV"); // Assuming you have defined your model in the manifest

        var aFilters = [
          new Filter("PurchaseContract", FilterOperator.EQ, sContractValue),
        ];

        try {
          var oData = await this._checkContractAvailability(oModel, aFilters);
          if ((oData.results && oData.results.length > 0) || (sContractToken.length > 0) ) {
            contractFlag = true;
          } else {
            sap.m.MessageToast.show( this._getTextfromi18n("PURCHASE_CONTRACT_NOT_AVL_MSG"));
            contractFlag = false;
          }
        } catch (oError) {
          MessageToast.show(
            this._getTextfromi18n("CONTRACT_AVL_CHECK_AVL_ERROR_MSG")
          );
        }     
        if(!contractFlag){
          this._setButtonEnabled(false);
        } else{
          this._setButtonEnabled(true);
        }
        
      },
      _checkContractAvailability: function (oModel, aFilters) {
        return new Promise(function (resolve, reject) {
          oModel.read("/A_PurchaseContract", {
            filters: aFilters,
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },
      _onCtrInputChange: function () { 
        var ctrValue =this.byId("idPurchaseingContract").getValue() ||this.byId("idPurchaseingContract").getTokens().length > 0;
        this._setButtonEnabled(!!ctrValue); 
      },
      onContractChange: function (oEvent) { 
        // var aTokens = oEvent.getParameter("tokens");
        var sType = oEvent.getParameter("type"),
        aAddedTokens = oEvent.getParameter("addedTokens"),
        aRemovedTokens = oEvent.getParameter("removedTokens"), 
        aContexts = this.getView().getModel("localModel").getProperty("/selectedMatCondition")

      switch (sType) {
        // add new context to the data of the model, when new token is being added
        case "added" :
          aAddedTokens.forEach(function (oToken) {
            aContexts.push({key: oToken.getKey(), text: oToken.getText() });
          });
          break;
        // remove contexts from the data of the model, when tokens are being removed
        case "removed" :
          aRemovedTokens.forEach(function (oToken) {
            aContexts = aContexts.filter(function (oContext) {
              return oContext.oValue1 !== oToken.getKey();
            });
          });
          break;
        default: break;
      }
      this.getView().getModel("localModel").setProperty("/selectedMatCondition", aContexts);
        this._onCtrInputChange()
      },
      //end-value help

      //function to identify the selected mode
      onModeSelectChange: function (oEvent) {
        var nSelectedIndex = oEvent.getParameter("selectedIndex");
        var mode = nSelectedIndex === 0 ? "Create" : "Change";
        this.getView().getModel("localModel").setProperty("/mode", mode);
      },

           //--------------functions for file download
           onDownloadPress: function () {
            BusyIndicator.show();
            this.getView()
              .getModel("localModel")
              .setProperty("/purchasedataToDownload", []);
            this.downloadPurchaseContract();
          },
    
          //function to download the purchase contract in excel file
          downloadPurchaseContract: function (nSkipToken) {
    
            var sPurchaseCOntacrFrom = this.getView()
              .byId("idPurchaseingContract")
              .getValue();
              let aContexts; 
              let singelFilter = [];
            if (sPurchaseCOntacrFrom) {
              var single =  new Filter({
                path: "PurchaseContract",
                operator: FilterOperator.EQ,
                value1: sPurchaseCOntacrFrom,
              });
              singelFilter.push(single)
              aContexts = singelFilter
            } else {
              aContexts = this.getView().getModel("localModel").getProperty("/selectedMatCondition");
              if (!aContexts.length > 0) {
                MessageToast.show(
                  this._getTextfromi18n("CONTRACT_NOT_VALID_MSG")
                );
                BusyIndicator.hide();
                return
                
              }
            }
                   
            var oParameter = {
              filters: aContexts,
    
              urlParameters: {paging:"cursor"},
              success: function (oData, oResponse) {
                var aPurchaseData = this.getView()
                  .getModel("localModel")
                  .getProperty("/purchasedataToDownload")
                aPurchaseData = aPurchaseData.concat(oData.results);
               
                if (oData.__next && oData.__next.split("$skiptoken=")[1]) {
                  this.getView().getModel("localModel").setProperty("/purchasedataToDownload", aPurchaseData);
                  this.downloadPurchaseContract(oData.__next.split("$skiptoken=")[1]);
                }
                else {
                   
                  if(aPurchaseData.length>0){
                    this.getView().getModel("localModel").setProperty("/purchasedataToDownload", aPurchaseData);
                  }
                  if (this.getView()
                    .getModel("localModel")
                    .getProperty("/purchasedataToDownload").length > 0) {
                      BusyIndicator.hide();
                    this._downloadExcel();
                    
                  }
                  else {
                    BusyIndicator.hide();
                    MessageToast.show( this._getTextfromi18n("NO_PO_FOUND_MSG"));
                  }
    
                }
    
              }.bind(this),
              error: function (oError) {
                MessageBox.error(
                  JSON.parse(oError.responseText).error.message.value
                );
                BusyIndicator.hide();
              }.bind(this),
            }; 
            if (nSkipToken) {
              oParameter.urlParameters = {
                "$skiptoken": nSkipToken,
               
                "paging":"cursor"
              };
            }
            var odataManagerModel = this.getOwnerComponent().getModel("Z_BIND_MM_PURCHASE_SCALES");
            
            odataManagerModel.read("/ZMM_CDS_I_PURCHASE_SCALES", oParameter);
          },

      //function to download excel file
      _downloadExcel: function () { 
        var aData = this.getView()
          .getModel("localModel")
          .getProperty("/purchasedataToDownload"); 
        const mappedData = aData.map((record) => ({ 
          PurchaseContract: record.PurchaseContract,
          PurchaseContractItem: record.Item_PurchaseContractItem,
          ValidityStartDate: record.ConditionStartDate_Conv,
          ValidityEndDate: record.ConditionEndDate_Conv, 
          ConditionType: record.ConditionType,
          ConditionScaleQuantity: (  record.ConditionScaleQuantity === 0 ||  record.ConditionScaleQuantity === "0.000000000" ||  record.ConditionScaleQuantity === "0.000")? "" :  record.ConditionScaleQuantity,
          ConditionScaleQuantityUnit: record.OrderPriceUnit,
          ScaleAmount: ( record.ScaleAmount === 0 || record.ScaleAmount === "0.000000000" || record.ScaleAmount === "0.000")? "" : record.ScaleAmount  ,
          Action : "Create/Change",
          ScaleLine : record.ConditionScaleLine 
        }));   
        //Amar Sort
        mappedData.sort((a,b)=>{
          const quantityA =parseFloat(a.ConditionScaleQuantity) || 0;
          const quantityB =parseFloat(b.ConditionScaleQuantity) || 0;
          return quantityA - quantityB;
        })
        var aColumns = [
          {
            label: "Contract# (No Changes)",
            property: "PurchaseContract",
            type: "String",
          },
          {
            label: "Item# (No Changes)",
            property: "PurchaseContractItem",
            type: "String",
          },
          {
            label: "Valid From (No Changes)",
            property: "ValidityStartDate",
            type: "String",
          },
          {
            label: "Valid To (No Changes)",
            property: "ValidityEndDate",
            type: "String",
          },
          {
            label: "Condition Type (No Changes)",
            property: "ConditionType",
            type: "String",
          },
          {
            label: "Scale quantity",
            property: "ConditionScaleQuantity" ,
            type: "String",
          },
          {
            label: "Scale UOM (No Changes)",
            property: "ConditionScaleQuantityUnit",
            type: "String",
          },
          {
            label: "Amount#",
            property: "ScaleAmount",
            type: "string",
          },
          {
            label: "ScaleLine (No Changes)",           
            property: "ScaleLine",
            type: "String",
          },
          {
            label: "Action",           
            property: "Action",
            type: "String",
          },
          
        ];

        var oSettings = {
          workbook: {
            columns: aColumns,
            hierarchyLevel: "Level",
          },
          dataSource: mappedData,
          fileName: "ScaleData.xlsx",
          worker: false, // We need to disable worker because we are using a MockServer as OData Service
        };

        var oSheet = new Spreadsheet(oSettings);
        oSheet.build().finally(function () {          
          oSheet.destroy();
          BusyIndicator.hide();
        });
        
       
      },

      _formatDate: function (dateString) {
        // Parse the date string into a Date object
        var date = new Date(dateString),
          mnth = ("0" + (date.getMonth() + 1)).slice(-2),
          day = ("0" + date.getDate()).slice(-2);
        return [date.getFullYear(), mnth, day].join("-");
      },
     
      convertToISODate : function (dateString) {
        var parts = dateString.split("/");
        var month = parseInt(parts[0], 10);
        var day = parseInt(parts[1], 10);
        var year = parseInt(parts[2], 10);
        year = year < 100 ? 2000 + year : year; 
                   
        var formattedDate = year.toString() + '-' +
                        ('0' + month).slice(-2) + '-' +
                        ('0' + day).slice(-2);
        return formattedDate + "T00:00:00";
    },
    formatDate: function (dateString) {
      const date = new Date(dateString);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
      const year = date.getFullYear();
      return `${day}-${month}-${year}`;
    },
     formatApiDate: function (dateString) {
      const date = new Date(dateString);
      const day = String(date.getDate()).padStart(2, '0');
      const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are zero-based
      const year = date.getFullYear();
      return `${year}-${month}-${day}`;
    },
    
      removeSpacesInKeys: function (obj) {
        let newObj = {};
        for (let key in obj) {
          if (obj.hasOwnProperty(key)) {
            let newKey = key.replace(/\s+/g, ""); //space removal
            newObj[newKey] = obj[key];
          }
        }
        return newObj;
      },

      // on click of browse button, to upload the file file explorer will open and user will selest the file.
      onFileUpload: function (oEvent) {
        var oFile =
          oEvent.getParameter("files") && oEvent.getParameter("files")[0];
        if (oFile) {
          this._oFile = oFile;
         
        }
      },
      //function to read the file and set data
      onUploadPress: async function () {
        BusyIndicator.show();
        var that  = this
        var submitResponsebody;      
         await this.onUploadPress_Hdr(); 
      //call custom API to do validation and convert the structure same as excelsheet data.
        that.excelSheetsData = await that._callUpdateValidateAPI(that, that.excelSheetsData);
      var createPayload = await that._callCreateAPI(that, that.excelSheetsData);
      var responseCreateValue , responseChangeValue
      if (createPayload.Create.length > 0 ) {
       

        responseCreateValue = await this.postbatchcall(createPayload.Create);  //createPayload.Create

      } 
      if (createPayload.Change.length > 0) {
      
        responseChangeValue = await this.patchbatchcall(createPayload.Change);
        
      }
       const combinedResult = this.combineJsonArrays(responseCreateValue, responseChangeValue);
  // call snd screen
if (combinedResult && combinedResult.length > 0) {
  var oModel = this.getView().getModel("localModel"); 
  oModel.setProperty("/responseExtract", combinedResult);   
  const oRouter =  this.getOwnerComponent().getRouter();
  oRouter.navTo("display");
  this.byId("idfileUploader").clear();
  BusyIndicator.hide();

}
BusyIndicator.hide();
  


      },
      onUploadPress_Hdr : function () {
        return new Promise((resolve, reject) => {
        try {
          if (this._oFile && window.FileReader) {
            var reader = new FileReader();
            var that = this;
            this.excelSheetsData = [];
            reader.onload = (e) => {
              // getting the binary excel file content
              let xlsx_content = e.currentTarget.result;

              let workbook = XLSX.read(xlsx_content, {
                type: "binary",
                cellText: false,
                cellDates: true,
              });

            
              workbook.SheetNames.forEach(function (sheetName) {
                
                const sheet = workbook.Sheets[sheetName];                
                const sheetData = XLSX.utils.sheet_to_row_object_array(sheet, {
                    raw: false,
                    defval: "",
                    dateNF: "yyyy-mm-dd"
                });            
                
                if (sheetData.length > 0) {
                    // Map the first row's keys (headers) to modified headers
                    const modifiedData = sheetData.map(row => {
                        const modifiedRow = {};
                        for (const key in row) {
                           
                            const modifiedKey = key.replace(/\s*\(No Changes\)\s*/gi, "");
                            modifiedRow[modifiedKey] = row[key];  // Copy data to modified key
                        }
                        return modifiedRow;
                    });           
                   
                    that.excelSheetsData.push(modifiedData);
                }


              });

              that.excelSheetsData = that.excelSheetsData.flat();
              that.excelSheetsData = that.excelSheetsData.map((item) =>
                that.removeSpacesInKeys(item)
              );
              that.excelSheetsData.forEach((item) => {
                item.ValidFrom = item.ValidFrom + "T00:00:00";
                item.ValidTo = item.ValidTo + "T00:00:00";
                if(item.hasOwnProperty('ScaleUOM')){
                  item['Scaleunitofmeasure'] = item['ScaleUOM'];
                }
              });
              resolve();
            };
            reader.readAsArrayBuffer(this._oFile);
            
          } else{
            BusyIndicator.hide();
            MessageToast.show( this._getTextfromi18n("NO_FILE_OR_NOT_SUPPORTED_MSG"));
            reject(this._getTextfromi18n("NO_FILE_OR_NOT_SUPPORTED_MSG"));
          }
        } catch (error) {
          BusyIndicator.hide();
          MessageToast.show( this._getTextfromi18n("READ_FILE_ERROR_MSG"));
          reject(error);
        }
      });
      },
                                     
       
      // function to display error on upload of file
      handleTypeMissmatch: function (oEvent) {
        var aFileTypes = oEvent.getSource().getFileType();
        aFileTypes.map(function (sType) {
          return "*." + sType;
        });
        MessageBox.error(
          this._getTextfromi18n("FILE_NOT_SUPPORTED_MSG")
        );
      },

      _callCreateAPI: async function (oContext, fileArray) {  
        return new Promise( async (resolve, reject) => {
try {  
  let completePayload = { Create: [], Change: [] };
  const result = fileArray.reduce((acc, record) => {
    if (record.Action === 'Create') {
        acc.Create.push(record);
    } else if (record.Action === 'Change') {
        acc.Change.push(record);
    }
    return acc;
}, { "Create": [], "Change": [] });

        //create payload
        var finalPayloadArray = [];
        const combinedRecords = [...result.Create, ...result.Change]
        const uniqueContracts = [...new Set(combinedRecords.map(record => record['Contract#']))];
        var aFilters = uniqueContracts.map(function(sMatNumber) {
          return new Filter("PurchaseContract", FilterOperator.EQ, sMatNumber);
      });

        var odataManagerModel = this.getOwnerComponent().getModel("Z_BIND_MM_PURCHASE_SCALES");
        var oData = await this._getctrAvailability(odataManagerModel, aFilters);      
        
        if  (result.Create && result.Create.length > 0 ) {     
        const payload = result.Create.map(record => {          
          const purchaseContract = record["Contract#"];
          const purchaseContractItem = record["Item#"];
         
          const conditionValidityEndDate = record.ValidTo.split("T")[0];  //`${year}-${month}-${day}`;
          const additionalData = oData.results.find(odataRecord => {
              return odataRecord.PurchaseContract === purchaseContract &&
                     odataRecord.Item_PurchaseContractItem === purchaseContractItem &&
                   odataRecord.ConditionEndDate_Conv === conditionValidityEndDate;
          });
          return {
              PurchaseContract: purchaseContract,
              PurchaseContractItem: purchaseContractItem,
              ConditionRecord: additionalData ? additionalData.ConditionRecord : "", // Fallback to empty string if not found
              ConditionSequentialNumber: additionalData ? additionalData.ConditionSequentialNumber : "", // Fallback to empty string if not found
              ConditionValidityEndDate: `${conditionValidityEndDate}T00:00:00`, //record.ValidTo,
              ConditionScaleQuantity: record.Scalequantity,
              ConditionScaleQuantityUnit: record.Scaleunitofmeasure,
              ConditionRateRatio: "0",
              ConditionRateRatioUnit: "",
              ConditionRateAmount: record["Amount#"],
              ConditionCurrency: additionalData ? additionalData.DocumentCurrency : "", //
              ConditionQuantity: "1",
              ConditionQuantityUnit: record.Scaleunitofmeasure,

              ConditionScaleLine:"",  //22-08 
              ConditionRateValue:record["Amount#"], //22-08
              ConditionRateValueUnit :additionalData ? additionalData.DocumentCurrency : "", //22-08
              PricingScaleType :"",  //22-08

              ExcelValidFrom: record["ValidFrom"],  //PS1 02-Oct Fut Changes
              ExcelCondition: record["ConditionType"] , //PS1 02-Oct Fut Changes
              ExcelScaleUOM: record["Scaleunitofmeasure"] , //PS1 02-Oct Fut Changes

              IMessage : record["IMessage"],
              MessageType : record["MessageType"]
          };
      }); 
      completePayload.Create = payload
    }
      if  (result.Change && result.Change.length > 0 ) {       
      
      const changePayload = result.Change.map(record => {          
        const purchaseContract = record["Contract#"];
        const purchaseContractItem = record["Item#"];
         
        const condScaleLine = record.ScaleLine;
       
        const conditionValidityEndDate = record.ValidTo.split("T")[0]; // `${year}-${month}-${day}`;
        const additionalData = oData.results.find(odataRecord => {
            return odataRecord.PurchaseContract === purchaseContract &&
                   odataRecord.Item_PurchaseContractItem === purchaseContractItem &&
                   odataRecord.ConditionScaleLine === condScaleLine  &&
                   odataRecord.ConditionEndDate_Conv === conditionValidityEndDate;
        });
        return {
            PurchaseContract: purchaseContract,
            PurchaseContractItem: purchaseContractItem,
            ConditionRecord: additionalData ? additionalData.ConditionRecord : "", // Fallback to empty string if not found
            ConditionSequentialNumber: additionalData ? additionalData.ConditionSequentialNumber : "", // Fallback to empty string if not found
            ConditionValidityEndDate: `${conditionValidityEndDate}T00:00:00`, //record.ValidTo,
            ConditionScaleLine : additionalData ? additionalData.ConditionScaleLine : "",
            ConditionScaleQuantity: record.Scalequantity,  //file
                                
            ConditionRateAmount: record["Amount#"],   //file

            ExcelValidFrom: record["ValidFrom"],  //PS1 02-Oct Fut Changes
            ExcelCondition: record["ConditionType"] , //PS1 02-Oct Fut Changes
            ExcelScaleUOM: record["Scaleunitofmeasure"] , //PS1 02-Oct Fut Changes

            IMessage : record["IMessage"],
            MessageType : record["MessageType"]
        };
    }); 
  completePayload.Change = changePayload
 }
      
    
     


resolve(completePayload);
} catch (error) {
  BusyIndicator.hide();
  reject(error)
}
});
      },
      

      _getctrAvailability: function (oModel, aFilters ) {          
        const that = this;
        return new Promise(function (resolve, reject) {
          function recursiveFunction (oModel, aFilters , nSkipToken){
      var oParameter = {
        filters: aFilters,
        urlParameters: {paging:"cursor"},
        success: function (othis,oFilter, oData, oResponse) {
          var aPurchaseData = that.getView()
            .getModel("localModel")
            .getProperty("/purchasedataToCheck")
            aPurchaseData.results = aPurchaseData.results.concat(oData.results);             
          if (oData.__next && oData.__next.split("$skiptoken=")[1]) {
            that.getView().getModel("localModel").setProperty("/purchasedataToCheck", aPurchaseData);
            recursiveFunction(oModel, aFilters, oData.__next.split("$skiptoken=")[1]);
          }
          else {                 
            if(aPurchaseData.results.length>0){
              that.getView().getModel("localModel").setProperty("/purchasedataToCheck", aPurchaseData);
            }
            if (that.getView().getModel("localModel").getProperty("/purchasedataToCheck").results.length > 0) { 
              var data = that.getView()
              .getModel("localModel")
              .getProperty("/purchasedataToCheck")
              resolve( data);           
            }
            else {
              BusyIndicator.hide();
              MessageToast.show(this._getTextfromi18n("NO_ADDNL_DATA_FOUND_FOR_PO_MSG"));
            }
          }
        }.bind(that , oModel, aFilters),
        error: function (oError) {
          MessageBox.error(
            JSON.parse(oError.responseText).error.message.value
          );
          reject(oError.responseText)
          BusyIndicator.hide();
        }.bind(that),
      }; 
      if (nSkipToken) {
        oParameter.urlParameters = {
          "$skiptoken": nSkipToken,           
          "paging":"cursor"
        };
      }
     
      oModel.read("/ZMM_CDS_I_PURCHASE_SCALES", oParameter);
      }
      recursiveFunction(oModel, aFilters)

          //end promise
        }.bind(this));
      },
       // batch call
       postbatchcall: function (payloadsArray) {
        return new Promise((resolve, reject) => {
          var oModel = this.oModel;
          var aDeferredGroups = oModel.getDeferredGroups();
          if (!aDeferredGroups.includes("scaleGroup")) {
            aDeferredGroups = aDeferredGroups.concat(["scaleGroup"]);
            oModel.setDeferredGroups(aDeferredGroups);          
          }

          if (payloadsArray && payloadsArray.length > 0) {

            for (let index = 0; index < payloadsArray.length; index++) {
              if (payloadsArray[index].MessageType === 'S') {
                let itemPayload = {...payloadsArray[index]};
                delete itemPayload.ExcelValidFrom;
                delete itemPayload.ExcelCondition;
                delete itemPayload.ExcelScaleUOM;
                delete itemPayload.IMessage;
                delete itemPayload.MessageType;
                oModel.create("/A_PurContrItmCndnScales", itemPayload , {
                  changeSetId: `ID_${index}`,
                  groupId: "scaleGroup",
                  success: function(odata){
                   payloadsArray[index].status = this._getTextfromi18n("RESPONSE.SUCCESS_STATUS");//"Success"
                   payloadsArray[index].message = this._getTextfromi18n("RESPONSE.CREATE_SUCCESS_MSG");//"Create Successful"
                   payloadsArray[index].action = this._getTextfromi18n("RESPONSE.CREATE");//"Create";
                  },
                  error: function(error,oHeader){
                    var sMessage="";
                    if( oHeader && oHeader.responseText ){  sMessage = JSON.parse(oHeader.responseText).error.message.value} else if(error && error.responseText){sMessage = JSON.parse(error.responseText).error.message.value}
                    payloadsArray[index].status =  this._getTextfromi18n("RESPONSE.ERROR_STATUS");//"Error";
                    payloadsArray[index].message = sMessage ||  this._getTextfromi18n("RESPONSE.CREATE_ERROR_MSG");//"Create Failed";
                    payloadsArray[index].action = this._getTextfromi18n("RESPONSE.CREATE");//"Create";
                  }
                });
              } else {
                payloadsArray[index].status = this._getTextfromi18n("RESPONSE.ERROR_STATUS");//"Error";
                payloadsArray[index].message = this._getTextfromi18n("RESPONSE.CREATE_ERROR_MSG");//"Create Failed";
                payloadsArray[index].action = this._getTextfromi18n("RESPONSE.CREATE");//"Create";
              }
            
            }
            oModel.submitChanges({
              groupId:"scaleGroup",
              success: (data) => {                            
                resolve(payloadsArray);
              },
              error: (error) => {     
                MessageBox.error(error.responseText);           
                BusyIndicator.hide();
                reject(error);                
              },
            });
            

          } else {
            resolve(); 
          }
        });
      },
  

      // //newpost
      patchbatchcall: function (payloadsArray ) {
        return new Promise((resolve, reject) => {
          var oModel = this.oModel;          
          oModel.setUseBatch(true);
          oModel.setDeferredGroups(["postCallsGroup"]);
          if (payloadsArray && payloadsArray.length > 0) {
            for (let index = 0; index < payloadsArray.length; index++) {

              if (payloadsArray[index].MessageType === 'S') {
                var sContentId = "CustomContentId-" + (index + 1);
                let payload = payloadsArray[index];
                let patchUrl =  `/A_PurContrItmCndnScales(PurchaseContract='${encodeURIComponent(payload.PurchaseContract)}',PurchaseContractItem='${encodeURIComponent(payload.PurchaseContractItem)}',ConditionRecord='${encodeURIComponent(payload.ConditionRecord)}',ConditionSequentialNumber='${encodeURIComponent(payload.ConditionSequentialNumber)}',ConditionValidityEndDate=datetime'${encodeURIComponent(payload.ConditionValidityEndDate)}',ConditionScaleLine='${encodeURIComponent(payload.ConditionScaleLine)}')`;
                let patchData = {
                  ConditionScaleQuantity: payload.ConditionScaleQuantity,
                  ConditionRateAmount: payload.ConditionRateAmount
              };
                oModel.update(patchUrl, patchData, {
                  groupId: "postCallsGroup",
                  changeSetId: sContentId,
                  method: "PATCH",
                  success: function (data, headercontentid) {                  
                    payloadsArray[index].status = this._getTextfromi18n("RESPONSE.SUCCESS_STATUS");//"Success";
                    payloadsArray[index].message = this._getTextfromi18n("RESPONSE.CHANGE_SUCCESS_MSG");//"Update Successful";
                    payloadsArray[index].action = this._getTextfromi18n("RESPONSE.CHANGE");//"Change";
                }.bind(this, payload),
                error: function (error, oHeader) {
                  var sMessage="";
                  if( oHeader && oHeader.responseText ){  sMessage = JSON.parse(oHeader.responseText).error.message.value}  else if(error && error.responseText){sMessage = JSON.parse(error.responseText).error.message.value}
                                
              payloadsArray[index].status = this._getTextfromi18n("RESPONSE.ERROR_STATUS");//"Error";
              payloadsArray[index].message = sMessage || this._getTextfromi18n("RESPONSE.CHANGE_ERROR_MSG");//"Update Failed";
              payloadsArray[index].action = this._getTextfromi18n("RESPONSE.CHANGE");//"Change";
                }.bind(this, payload),
                });
              } else {
                payloadsArray[index].status = this._getTextfromi18n("RESPONSE.ERROR_STATUS");//"Error";
                payloadsArray[index].message = this._getTextfromi18n("RESPONSE.CHANGE_ERROR_MSG");//"Update Failed";
                payloadsArray[index].action = this._getTextfromi18n("RESPONSE.CHANGE");//"Change";
              }
            
            }
            oModel.submitChanges({
              groupId: "postCallsGroup",
              success: (data , header) => {               
                resolve(payloadsArray)
              },
              error: (error) => {                
                MessageBox.error(error.responseText);
                BusyIndicator.hide();
                reject(error);                
              },
            });
          } else {
            resolve(); 
          }
        });
      },

      showPopupWithResults : function (response , changeresponse) {
        const tableData = this.processResponse(response , changeresponse);
        const oTable = new sap.m.Table({
            inset: true,
            columns: [
                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.ACTION}" }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: "{{i18n>RESPONSE_DETAILS.CONTRACT_NO}" }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.PURCHASECONTRACT_ITEM_NO}" }) }),

                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_RECORD}" }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_SEQ_NO}" }) }),               
                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_SCALE_QTY}" }) }),

                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.SCALE_UOM}" }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.AMT}" }) }),


                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_TYPE}" }) }),
                new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.RESULT}" }) })
            ]
        });
    
       
        tableData.forEach(rowData => {
            const cells = [];
    
            for (const key in rowData) {
                if (rowData.hasOwnProperty(key)) {
                    cells.push(new sap.m.Text({ text: rowData[key] }));
                }            }
    
            const oRow = new sap.m.ColumnListItem({ cells: cells });
            oTable.addItem(oRow);
        });
        const oDialog = new sap.m.Dialog({
            title: "{i18n>RESPONSE_DETAILS.TITLE}",
            contentWidth: "80%",
            contentHeight: "80%",
            draggable: true,
            resizable: true,
            content: oTable,
            endButton: new sap.m.Button({
                text: "{i18n>RESPONSE_DETAILS.CLOSE}",
                press: function () {
                    oDialog.close();
                }
            })
        });
        this.getView().addDependent(oDialog);
 oDialog.open();
    },
         
  
   

  processResponse: function (response, patchresponse) {
    const resultTable = [];

    // Function to process each individual response
    function processSingleResponse(response) {
        response.__batchResponses.forEach(batchResponse => {
            // Process change responses
            if (batchResponse.__changeResponses) {
                batchResponse.__changeResponses.forEach(changeResponse => {
                    const row = {};

                    if (changeResponse.statusCode && changeResponse.statusCode.startsWith("2")) {
                        try {
                            const bodyData = JSON.parse(changeResponse.body).d;
                            row["Action"] = "Create";
                            row["Contract#"] = bodyData.PurchaseContract;
                            row["Item#"] = bodyData.PurchaseContractItem;
                            row["ConditionRecord"] = bodyData.ConditionRecord;
                            row["ConditionSequentialNumber"] = bodyData.ConditionSequentialNumber;
                            row["Scalequantity"] = bodyData.ConditionScaleQuantity;
                            row["Scaleunitofmeasure"] = bodyData.ConditionScaleQuantityUnit;
                            row["Amount#"] = bodyData.ConditionRateAmount;
                            row["ConditionType"] = bodyData.ConditionType || "";
                            row["Result"] = `${changeResponse.statusCode}: ${changeResponse.statusText}`;
                        } catch (error) {
                            row["Result"] = `Error: ${error.message}`;
                        }
                    } else { // Handle errors
                        try {
                            const bodyData = changeResponse.body ? JSON.parse(changeResponse.body).error : {};
                            row["Action"] = "Error";
                            row["Contract#"] = bodyData.PurchaseContract || "N/A";
                            row["Item#"] = bodyData.PurchaseContractItem || "N/A";
                            row["ConditionRecord"] = bodyData.ConditionRecord || "N/A";
                            row["ConditionSequentialNumber"] = bodyData.ConditionSequentialNumber || "N/A";
                            row["Scalequantity"] = bodyData.ConditionScaleQuantity || "N/A";
                            row["Scaleunitofmeasure"] = bodyData.ConditionScaleQuantityUnit || "N/A";
                            row["Amount#"] = bodyData.ConditionRateAmount || "N/A";
                            row["ConditionType"] = bodyData.ConditionType || "N/A";
                            row["Result"] = `Error: ${changeResponse.statusCode || "Unknown"} - ${changeResponse.statusText || "Unknown"}`;
                            if (bodyData.message) {
                                row["Message"] = bodyData.message.value || "No message provided";
                            }
                        } catch (error) {
                            row["Result"] = `Error: ${error.message}`;
                        }
                    }

                    resultTable.push(row);
                });
            } else if (batchResponse.headers && batchResponse.headers['content-type'] && batchResponse.headers['content-type'].includes('multipart/mixed')) {
                // Handle multipart/mixed responses
                const boundary = batchResponse.headers['content-type'].split('boundary=')[1];
                const parts = batchResponse.body.split(`--${boundary}`);

                parts.forEach(part => {
                    if (part.trim() && part.includes('Content-Type: application/http')) {
                        const httpResponse = part.split('\r\n\r\n')[1]; // Get the HTTP response part
                        const [statusLine, ...headersAndBody] = httpResponse.split('\r\n');
                        const [protocol, statusCode, statusText] = statusLine.split(' ');
                        const body = headersAndBody.join('\r\n').trim();

                        const row = {};
                        if (statusCode.startsWith("2")) {
                            try {
                                const bodyData = JSON.parse(body).d;
                                row["Action"] = "Create";
                                row["Contract#"] = bodyData.PurchaseContract;
                                row["Item#"] = bodyData.PurchaseContractItem;
                                row["ConditionRecord"] = bodyData.ConditionRecord;
                                row["ConditionSequentialNumber"] = bodyData.ConditionSequentialNumber;
                                row["Scalequantity"] = bodyData.ConditionScaleQuantity;
                                row["Scaleunitofmeasure"] = bodyData.ConditionScaleQuantityUnit;
                                row["Amount#"] = bodyData.ConditionRateAmount;
                                row["ConditionType"] = bodyData.ConditionType || "";
                                row["Result"] = `${statusCode}: ${statusText}`;
                            } catch (error) {
                                row["Result"] = `Error: ${error.message}`;
                            }
                        } else {
                            try {
                                const bodyData = JSON.parse(body).error || {};
                                row["Action"] = "Error";
                                row["Contract#"] = bodyData.PurchaseContract || "N/A";
                                row["Item#"] = bodyData.PurchaseContractItem || "N/A";
                                row["ConditionRecord"] = bodyData.ConditionRecord || "N/A";
                                row["ConditionSequentialNumber"] = bodyData.ConditionSequentialNumber || "N/A";
                                row["Scalequantity"] = bodyData.ConditionScaleQuantity || "N/A";
                                row["Scaleunitofmeasure"] = bodyData.ConditionScaleQuantityUnit || "N/A";
                                row["Amount#"] = bodyData.ConditionRateAmount || "N/A";
                                row["ConditionType"] = bodyData.ConditionType || "N/A";
                                row["Result"] = `Error: ${statusCode} - ${statusText}`;
                                if (bodyData.message) {
                                    row["Message"] = bodyData.message.value || "No message provided";
                                }
                            } catch (error) {
                                row["Result"] = `Error: ${error.message}`;
                            }
                        }

                        resultTable.push(row);
                    }
                });
            }
        });
    }

    // Process both responses and merge the results into one table
    processSingleResponse(response);
    processSingleResponse(patchresponse);

    return resultTable;
},


parseBatchResponse : function (batchResponse) {
  const result = { responses: [] };

  
  const mainBoundaryMatch = batchResponse.match(/--([A-F0-9]+)\r\n/);
  if (!mainBoundaryMatch) {
   
    return result;
  }
  const mainBoundary = mainBoundaryMatch[1];

 
  const mainParts = batchResponse.split(`--${mainBoundary}`);

  mainParts.forEach(part => {
    
    const innerBoundaryMatch = part.match(/boundary=([A-F0-9]+)/);
    const innerBoundary = innerBoundaryMatch ? innerBoundaryMatch[1] : null;
    
    if (innerBoundary) {
     
      const innerParts = part.split(`--${innerBoundary}`);

      innerParts.forEach(innerPart => {
        if (innerPart.includes("HTTP/1.1")) {
          const response = {};

          const statusLineMatch = innerPart.match(/HTTP\/1\.1\s(\d{3})\s(.*)/);
          if (statusLineMatch) {
            response.status = `${statusLineMatch[1]} ${statusLineMatch[2]}`;
          }

          
          const contentIdMatch = innerPart.match(/content-id:\s(id-[\w-]+)/i);
          response.content_id = contentIdMatch ? contentIdMatch[1] : "";

          
          const contentTypeMatch = innerPart.match(/Content-Type: application\/json;?.*?\r\n/i);

          if (contentTypeMatch) {
           
            const jsonMatch = innerPart.match(/{.*}/s);
            if (jsonMatch) {
              try {
                const errorJson = JSON.parse(jsonMatch[0]);
               
                response.status = `${statusLineMatch[1]} ${statusLineMatch[2]}`;
                response.content_id = ""; 
                response.description =
                  errorJson.error?.message?.value || "Unknown error message"; 
                
              } catch (e) {
                response.description = "Error parsing JSON"; //
              }
            } else {
              response.description = "Unknown JSON Error"; //
            }
          } else {
          
            const descriptionMatch = innerPart.match(/dataserviceversion:\s\d+\.\d+\r\n(.*)\r\n/i);
            response.description = descriptionMatch ? descriptionMatch[1].trim() : "";
          }

          result.responses.push(response);
        }
      });
    }
  });

  return result;
},
combineJsonArrays:function (array1, array2) {
  
  const fieldsToExtract = [
    "ConditionRateAmount",
    "ConditionScaleQuantity",
    "ExcelScaleUOM",
    "ExcelValidFrom",
    "ConditionValidityEndDate",
    "ExcelCondition",
    "PurchaseContract",
    "PurchaseContractItem",
    "action",
    "message",
    "status",
    "IMessage",
    "MessageType"
  ];

  // Function to extract only the specific fields from an object
  const extractFields = (item) => {
    let extractedItem = {};
    fieldsToExtract.forEach(field => {
      if (item.hasOwnProperty(field)) {
        if (field === "ExcelValidFrom" || field === "ConditionValidityEndDate") {
          extractedItem[field] = item[field] ? item[field].split('T')[0] : "";
        } else {
          extractedItem[field] = item[field];
        }
        
      } else {
        extractedItem[field] = ""; 
      }
    });
    return extractedItem;
  };

  // Handle empty arrays and extract fields
  const filteredArray1 = (Array.isArray(array1) ? array1 : []).map(item => extractFields(item));
  const filteredArray2 = (Array.isArray(array2) ? array2 : []).map(item => extractFields(item));

  // Combine the filtered arrays
  return [...filteredArray1, ...filteredArray2];
},
showPopupWithResultsfinal: function (tableData) {
  

  // Create the table with columns that match the fields of the JSON structure
  const oTable = new sap.m.Table({
      inset: true,
      columns: [
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_RATE_AMT}" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_SCALE_QTY}" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.COND_VALID_END_DT}" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.PURCHASECONTRACT}" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.PURCHASECONTRACT_ITEM}" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.ACTION}" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.MESSAGE" }) }),
          new sap.m.Column({ header: new sap.m.Label({ text: "{i18n>RESPONSE_DETAILS.STATUS}" }) })
      ]
  });

  // Populate the table with rows from the tableData
  tableData.forEach(rowData => {
      const cells = [];
      
      // Populate cells with values from rowData
      cells.push(new sap.m.Text({ text: rowData.ConditionRateAmount || "" }));
      cells.push(new sap.m.Text({ text: rowData.ConditionScaleQuantity || "" }));
      cells.push(new sap.m.Text({ text: rowData.ConditionValidityEndDate || "" }));
      cells.push(new sap.m.Text({ text: rowData.PurchaseContract || "" }));
      cells.push(new sap.m.Text({ text: rowData.PurchaseContractItem || "" }));
      cells.push(new sap.m.Text({ text: rowData.action || "" }));
      cells.push(new sap.m.Text({ text: rowData.message || "" }));
      cells.push(new sap.m.Text({ text: rowData.status || "" }));

      const oRow = new sap.m.ColumnListItem({ cells: cells });
      oTable.addItem(oRow);
  });

  // Create and open the dialog with the table
  const oDialog = new sap.m.Dialog({
      title: "{i18n>RESPONSE_DETAILS.TITLE}",
      contentWidth: "80%",
      contentHeight: "80%",
      draggable: true,
      resizable: true,
      content: oTable,
      endButton: new sap.m.Button({
          text: "Close",
          press: function () {
              oDialog.close();
          }
      })
  });
  this.getView().addDependent(oDialog);
  oDialog.open();
},

//  Error Handling
_callUpdateValidateAPI: function (oContext , oExcelData) {
        
  return new Promise(function (resolve, reject) {
  var aValidationPayload = {
    "Seq_No": "1",
    "File_Upload": "X",
    "Tot_Records": "",
    "Ok_Records": "",
    "Err_Records": "",
    "Scale_File": []
      };
      oExcelData.forEach((record , index)=>{
        const formattedRecord = {
          Seq_No: String(index + 1),
          Contract: record ["Contract#"] || "",
          Item: record ["Item#"] || "",
          CondValidFrom: record ["ValidFrom"] || "",
          CondValidTo: record ["ValidTo"] || "",
          ConditionType: record ["ConditionType"] || "",  
          ScaleQty: record ["Scalequantity"] || "", 
          ScaleUOM: record ["ScaleUOM"] || "",
          Amount: record ["Amount#"] || "",
          ScaleLine: record ["ScaleLine"] || "",  
          Action: record ["Action"] || ""
        };
      
        
        aValidationPayload.Scale_File.push(formattedRecord);
      })
var oModel = oContext.getOwnerComponent().getModel("ZMM_CONTRACT_VALIDATE_SRV");
oModel.create("/ET_ScaleHeaderSet", aValidationPayload, {
  success: function (data) {  
          
           var addedExcel = oContext._addMessageToExcel(oExcelData , data)
           resolve(addedExcel)
  }.bind(oContext),
  error: function (error) {
    BusyIndicator.hide();
  reject(error)
  }.bind(oContext)
});
  });


},  //call update validator end

//add messages to the payload
_addMessageToExcel : function ( oExcel , oResponseData) {

  const compareDates = (date1, date2) => new Date(date1).getTime() === new Date(date2).getTime();


  oExcel.forEach((record) => {
    // Find the corresponding records in the responseData that match the contract, item, start, and end dates
    const matchedMessages = oResponseData.Scale_File.results.filter(
      (res) =>
        res.Contract === record["Contract#"] &&
        res.Item === record["Item#"] &&
        res.ConditionType === record["ConditionType"] &&
        res.ScaleLine === record["ScaleLine"] &&
        res.Amount === record["Amount#"] &&
        res.ScaleQty === record["Scalequantity"] &&
        res.CondValidFrom === record["ValidFrom"] &&
        res.CondValidTo === record["ValidTo"]
    );
  
  
    const iMessageArray = matchedMessages.map((msg) => ({
      MessageType: msg.MessageType,
      Message: msg.Message
    }));
  
    
    record.IMessage = iMessageArray;
    record.MessageType = matchedMessages.length > 0 ? matchedMessages[0].MessageType : '';
  });
return oExcel;
}, // add message to excel end
_getTextfromi18n : function(sKey, aPlaceholderParam){
  var oResourceModel = this.getView().getModel("i18n"),
    oBundle = oResourceModel.getResourceBundle(),
    sText = oBundle.getText(sKey,aPlaceholderParam);
    return sText;
}
    });
  }
);
